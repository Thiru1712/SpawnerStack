# SpawnerVault

**SpawnerVault** is a low-lag virtual spawner system for Paper 26.2.

**Powered by Rypera**  
**Development team: ForgeLabs**

## Design
- Vanilla spawner types only: Zombie, Skeleton, Spider, Cave Spider, Silverfish, Blaze, Magma Cube.
- No Enderman spawner by default.
- No physical mobs are spawned for production.
- Production runs on a shared scheduler instead of one task per spawner.
- Default cooldown: 60 seconds.
- Stack limit: 64.
- Production scales linearly with stack size.
- Storage scales linearly: 36 virtual slots × stack size.
- Normal item stack rules are preserved; non-stackable items such as bows consume one virtual slot.
- Storage is paginated and lazy-rendered for mobile/Geyser players.
- Loot can be collected, sold, or left stored.
- XP is stored separately and can be collected.
- Silk Touch is required to recover a spawner.
- Only iron, diamond and netherite pickaxes qualify.
- Renaming a qualifying pickaxe does not matter; actual material + Silk Touch are checked.
- A stacked spawner breaks into one stacked spawner item, retaining storage/XP/upgrades.
- Separate `prices.yml`, `spawners.yml`, and `messages.yml` make administration easy.

## Build
Requires Java 25 and Gradle. The build produces `SpawnerVault-1.0.0.jar`.

## Important
This v4 package is a **JAR-ready source release**. It must be compiled and tested against your exact Paper 26.2 server before production use. Do not copy an untested JAR into a live server.
