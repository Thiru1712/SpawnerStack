# Changelog

## 1.1.0
- Added optional Vault economy integration for Sell Loot.
- Removed SpawnerVault's internal player balance storage and starting balance.
- Sell Loot now deposits into the server's active Vault economy provider.
- Loot is removed only after a successful economy transaction.
- Added the admin placed-spawner management GUI under `/sv list`.
- Added persistent owner, placement timestamp, location, teleport, and direct management details.
- Removed the player-facing `/sv balance` command.
- Restricted SpawnerVault commands to `spawnervault.admin`.

## 1.0.1
- Removed the player-facing `/sv balance` command.
- Restricted SpawnerVault commands to `spawnervault.admin`.
- Added `/sv list` with a paginated admin placed-spawner GUI.
- Added persistent owner, placement timestamp, and location details for placed spawners.
- Added admin spawner detail view with teleport and direct management GUI access.
- Preserved owner metadata through Silk Touch recovery and re-placement.

