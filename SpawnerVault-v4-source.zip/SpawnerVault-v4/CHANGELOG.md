# SpawnerVault v1.0.0

Initial public-oriented architecture for the Mettioli SMP build.

- Virtual-only production
- Shared production scheduler
- Seven vanilla spawner types
- Stack scaling to 64
- 36 virtual storage slots per spawner unit
- Paginated mobile-friendly storage UI
- Loot collection and direct selling
- Separate prices.yml / spawners.yml / messages.yml
- Silk Touch + iron/diamond/netherite recovery rules
- Stacked recovery as one spawner item
- Persistent storage and XP
