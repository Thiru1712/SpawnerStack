# Installation

1. Build the project with Java 25 and Gradle.
2. The output JAR is `SpawnerVault-1.0.0.jar`.
3. Upload the JAR to `plugins/` on a Paper 26.2 server.
4. Restart the server.
5. Review `plugins/SpawnerVault/prices.yml`, `spawners.yml`, `messages.yml`, and `config.yml`.
6. Use `/sv reload` after configuration changes.

Do not install this uncompiled source ZIP into `plugins/`.

For Mettioli SMP, test this on the disposable development world first. Natural spawner-generation changes are intentionally separate from this plugin and should be applied to the final world-generation setup.
