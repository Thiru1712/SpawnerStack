plugins { java }
group = "com.spawnervault"
version = "1.1.0"
repositories { maven { name = "papermc"; url = uri("https://repo.papermc.io/repository/maven-public/") } }
dependencies { compileOnly("io.papermc.paper:paper-api:26.2.build.+") }
java { toolchain.languageVersion.set(JavaLanguageVersion.of(25)) }
tasks.withType<JavaCompile>().configureEach { options.encoding = "UTF-8" }
tasks.jar { archiveBaseName.set("SpawnerVault") }
