# Third-Party Notices

## Runtime JAR

SpawnerVault 1.1.0 does not bundle third-party runtime libraries in the
published JAR. The JAR contains the SpawnerVault classes and its plugin
resource files.

## Paper API

Paper API is a compile-time dependency used to build SpawnerVault. It is
provided by the Minecraft server at runtime and is not bundled into the
SpawnerVault JAR.

Paper project and licensing information:
https://github.com/PaperMC/Paper

## Notice

This file is a project-level notice. If a future release bundles additional
libraries, their names, licenses, copyright notices, and required attribution
must be added here before that release is published.

## VaultAPI

VaultAPI is a compile-time dependency used for optional economy integration.
It is not bundled into the SpawnerVault JAR.

Project: https://github.com/MilkBowl/VaultAPI  
License: LGPL-3.0
