# Changelog

## 1.1.2
- Fixed BlockPlaceEvent null handling.
- Every normal `minecraft:spawner` is adopted by SpawnerVault regardless of mob type.
- Trial Spawners are explicitly excluded.
- Added periodic loaded-chunk adoption for command/plugin-created normal spawners.
- Removed the hard 7-type adoption restriction.
- Kept the seven configured vanilla loot profiles; unconfigured mob types remain managed but produce no invented drops until a profile is configured.
- Preserved Silk Touch recovery rules and virtual-only spawning.

# Changelog

## 1.1.1
- Fixed BlockPlaceEvent NullPointerException when a spawner type is absent.
- Normal `minecraft:spawner` blocks are now automatically adopted by SpawnerVault, including naturally generated and command/plugin-created spawners.
- Spawner adoption now supports every valid normal spawner mob type instead of restricting management to seven types.
- `minecraft:trial_spawner` remains completely untouched.
- Existing normal spawners are adopted on startup and chunk load.
- Adopted spawners have their vanilla physical spawning disabled and use SpawnerVault virtual management.
- Removed the admin Silk Touch bypass: SpawnerVault recovery always requires Iron/Diamond/Netherite + Silk Touch.
- Spawner break handling now adopts an unregistered normal spawner before enforcing recovery rules.
- Persistent block PDC marks managed spawners and records their type/stack.

# Changelog

## 1.1.0
- Added optional Vault economy integration for Sell Loot.
- Removed SpawnerVault's internal player balance storage and starting balance.
- Sell Loot now deposits into the server's active Vault economy provider.
- Loot is removed only after a successful economy transaction.
- Added the admin placed-spawner management GUI under `/sv list`.
- Added persistent owner, placement timestamp, location, teleport, and direct management details.
- Removed the player-facing `/sv balance` command.
- Restricted SpawnerVault commands to `spawnervault.admin`.

## 1.0.1
- Removed the player-facing `/sv balance` command.
- Restricted SpawnerVault commands to `spawnervault.admin`.
- Added `/sv list` with a paginated admin placed-spawner GUI.
- Added persistent owner, placement timestamp, and location details for placed spawners.
- Added admin spawner detail view with teleport and direct management GUI access.
- Preserved owner metadata through Silk Touch recovery and re-placement.

