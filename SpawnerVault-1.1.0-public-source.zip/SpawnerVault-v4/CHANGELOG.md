# Changelog

## 1.1.0

- Added the admin `/sv list` placed-spawner management GUI.
- Added spawner detail view with owner, type, stack size, placement time and location.
- Added admin teleport and management actions.
- Removed the internal SpawnerVault player-balance system.
- Added optional Vault-compatible economy integration for Sell Loot.
- Selling now credits the server economy and only removes loot after a successful transaction.

## 1.1.0
- Added the admin placed-spawner management GUI under `/sv list`.
- Added persistent owner, placement timestamp, location, teleport, and direct management details.
- Removed the player-facing `/sv balance` command.
- Restricted SpawnerVault commands to `spawnervault.admin`.

## 1.0.1
- Removed the player-facing `/sv balance` command.
- Restricted SpawnerVault commands to `spawnervault.admin`.
- Added `/sv list` with a paginated admin placed-spawner GUI.
- Added persistent owner, placement timestamp, and location details for placed spawners.
- Added admin spawner detail view with teleport and direct management GUI access.
- Preserved owner metadata through Silk Touch recovery and re-placement.

