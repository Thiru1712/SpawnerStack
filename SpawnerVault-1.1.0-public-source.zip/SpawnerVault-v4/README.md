# SpawnerVault

**SpawnerVault** is a Paper plugin for virtual vanilla spawner production,
stacking, storage, and collection.

**Development team:** ForgeLabs  
**Company/brand:** Rypera  
**Branding:** Powered by Rypera

## Supported Platform

- Paper 26.2
- Java 25

## Features

- Vanilla spawner types only:
  - Zombie
  - Skeleton
  - Spider
  - Cave Spider
  - Silverfish
  - Blaze
  - Magma Cube
- No custom mob types.
- No Enderman spawner.
- Virtual production without requiring production mobs.
- Shared production scheduling design for low overhead.
- Configurable production cooldown.
- Spawner stack limit of 64.
- Production scales with stack size.
- Virtual storage scales at **36 slots per spawner**.
- Normal Minecraft item stack rules are preserved, including non-stackable
  items consuming individual virtual slots.
- Paginated storage UI intended to be mobile/Geyser friendly.
- Separate virtual XP storage.
- Persistent spawner data.
- Silk Touch recovery using supported pickaxe tiers.
- Stacked spawners are represented as one stacked spawner item when recovered.
- Administration files are separated into `config.yml`, `spawners.yml`,
  `prices.yml`, and `messages.yml`.

## Installation

1. Download the JAR from the official project release.
2. Put `SpawnerVault-1.1.0.jar` in `plugins/`.
3. Start or restart the Paper server.
4. Check the console for a successful SpawnerVault enable message.
5. Review the generated plugin configuration.

See [INSTALL.md](INSTALL.md) for additional details.

## Admin Commands

SpawnerVault has no player-facing commands. Its command interface is restricted to `spawnervault.admin` (default: server operators).

The optional **Sell Loot** feature integrates with the server economy through Vault; SpawnerVault does not maintain a separate player balance system.

- `/sv reload` — reload SpawnerVault configuration.
- `/sv give <player> <type> [amount]` — give an allowed vanilla spawner stack.
- `/sv list` — open the paginated placed-spawner management GUI.

### Admin placed-spawner GUI

`/sv list` opens a chest-style GUI containing placed SpawnerVault spawners. Clicking one opens its details, including:

- spawner type
- stack size
- player who placed it
- placement date/time
- world and XYZ coordinates
- teleport button
- button to open the normal SpawnerVault GUI for management

The placed-spawner records are persisted across restarts and survive Silk Touch recovery/replacement.

## Configuration

### `config.yml`

General plugin behavior and performance-related settings.

### `spawners.yml`

Spawner-specific definitions and settings.

### `prices.yml`

Administrative item pricing configuration. Prices are used by the optional Vault economy integration when players sell stored loot. SpawnerVault does not store player balances.

### `messages.yml`

Player-facing messages.

## Building From Source

The project uses Gradle and Java 25.

```bash
gradle clean build --no-daemon
```

The build output is `build/libs/SpawnerVault-1.1.0.jar`.

## Compatibility

SpawnerVault is developed for Paper. Compatibility with other Bukkit-derived
servers is not guaranteed unless explicitly tested and documented.

## Support

When reporting a problem, include the SpawnerVault version, Paper version,
Java version, relevant console output, and reproducible steps.

## License

SpawnerVault is licensed under the MIT License. See [LICENSE](LICENSE).

## Third-Party Notices

See [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md).

## Disclaimer

SpawnerVault is an independent community plugin and is not affiliated with,
endorsed by, or an official product of Mojang Studios or Microsoft.
